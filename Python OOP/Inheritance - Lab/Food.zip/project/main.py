from project.fruit import Fruit

f = Fruit("23.11.2022", "Banana")

print(f.expiration_date)
print(f.name)